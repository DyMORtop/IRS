import sys
from PyQt5 import QtWidgets
from PyQt5.QtWidgets import *
import design, auth, conn, parse, showinfo_load, DepartmentBtn, RetirementBtn, ExportBtn, export, admin
import re


class ExportDialog(QtWidgets.QDialog, export.Ui_Export):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.AllCheckBox.stateChanged.connect(self.Change_state)

    def Change_state(self):
        self.SurnameCheckBox.setChecked(self.AllCheckBox.isChecked())
        self.NameCheckBox.setChecked(self.AllCheckBox.isChecked())
        self.MiddlenameCheckBox.setChecked(self.AllCheckBox.isChecked())
        self.BirthdayCheckBox.setChecked(self.AllCheckBox.isChecked())
        self.CityCheckBox.setChecked(self.AllCheckBox.isChecked())
        self.SerialNumberCheckBox.setChecked(self.AllCheckBox.isChecked())
        self.DatePasportCheckBox.setChecked(self.AllCheckBox.isChecked())
        self.PlaceOfIssueCheckBox.setChecked(self.AllCheckBox.isChecked())
        self.INNCheckBox.setChecked(self.AllCheckBox.isChecked())
        self.InsuranceNumberCheckBox.setChecked(self.AllCheckBox.isChecked())
        self.HomeAddressCheckBox.setChecked(self.AllCheckBox.isChecked())
        self.DegreeCheckBox.setChecked(self.AllCheckBox.isChecked())
        self.SpecialtyCheckBox.setChecked(self.AllCheckBox.isChecked())
        self.DepartmentCheckBox.setChecked(self.AllCheckBox.isChecked())
        self.PositionCheckBox_2.setChecked(self.AllCheckBox.isChecked())
        self.SalaryCheckBox.setChecked(self.AllCheckBox.isChecked())
        self.DateOfReceiptCheckBox.setChecked(self.AllCheckBox.isChecked())

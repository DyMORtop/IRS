def parse(field):
    if field == '':
        return '%'
    return field

def parseAdd(field):
    if field == '':
        return False
    return True

import sys
from PyQt5 import QtWidgets
from PyQt5.QtWidgets import *
from MainWindow import Main_Window
import design, auth, conn, parse, showinfo_load, DepartmentBtn, RetirementBtn, ExportBtn, export, admin
import re

class ExampleAuth(QtWidgets.QDialog, auth.Ui_Dialog):
    
    keys = [False, False]
    
    def __init__(self):

        super().__init__()
        self.setupUi(self)
        self.was_Okbutton_clicked = False
        self.Ok.clicked.connect(self.check_is_not_empty)
        self.Cancel.clicked.connect(self.close_window)

    def close_window(self):
        self.keys[0] = True
        self.close()

    def closeEvent(self, event):
        if self.was_Okbutton_clicked == False:
            self.keys[0] = True
            event.accept()
        else:
            self.keys[0] = False
            event.accept()

    def check_is_not_empty(self):
        
        if (len(self.loginLine.text())) == 0 and (len(self.passwordLine.text())) == 0:
            QMessageBox.warning(None, 'Warning', 'Login and password are needed!')
            return False

        if self.isAdmin():
            self.keys[1] = True

        self.was_Okbutton_clicked = True
        self.close()
        
        return True
        

    def isAdmin(self):
        if self.loginLine.text() == 'admin' and self.passwordLine.text() == 'admin':
            return True
        else:
            return False

import sys
sys.path.append('Interface/')
sys.path.append('DataBase/')
import csv

from PyQt5 import QtWidgets
from PyQt5.QtWidgets import *

import main_design, connection, data_base_commands
from export_window import ExportWindow
from admin_window import AdminWindow
import re

class MainWindow(QtWidgets.QMainWindow, main_design.Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.Find.clicked.connect(self.find)
        self.ShowInfo.clicked.connect(self.fill_page_result)
        self.RefreshDepartment.clicked.connect(self.fill_department_table)
        self.RefreshRetirement.clicked.connect(self.fill_retirement_table)
        self.Export.clicked.connect(self.export)
        self.AdminBtn.clicked.connect(self.admin_panel)

        self.fill_fullname_combobox()

        connection.query('birthplace')
        cities = connection.response()
        for i in range(len(cities)):
            cities[i] = re.sub('\(|\)|\'|,', '', cities[i])
        self.PlaceOfBirthComboBox.addItems(cities)
        
        connection.query('specialization')
        specialties = connection.response()
        for i in range(len(specialties)):
            specialties[i] = re.sub('\(|\)|\'|,', '', specialties[i])
        self.SpecialtyComboBox.addItems(specialties)

        connection.query('department')
        departments = connection.response()
        for i in range(len(departments)):
            departments[i] = re.sub('\(|\)|\'|,', '', departments[i])
        self.DepartmentComboBox.addItems(departments)

        connection.query('position')
        positions = connection.response()
        for i in range(len(positions)):
            positions[i] = re.sub('\(|\)|\'|,', '', positions[i])
        self.PositionComboBox.addItems(positions)

        connection.query('salary')
        salaries = connection.response()
        for i in range(len(salaries)):
            salaries[i] = re.sub('\(|\)|\'|,', '', salaries[i])
        self.SalaryComboBox.addItems(salaries)

        connection.query('datereceipt')
        dates = connection.response()
        for i in range(len(dates)):
            dates[i] = re.sub('\(|\)|\'|,', '', dates[i])
        self.DateOfReceiptComboBox.addItems(dates)

    def fill_fullname_combobox(self):
        self.FullNameComboBox.clear()
        connection.query('init')
        res = connection.init_response()
        for i in range(len(res)):
            res[i] = re.sub('\(|\)|\'|,', '', res[i])
        self.FullNameComboBox.addItems(res)

    def fill_table_retirement(self):
        result = []
        connection.query('RetirementAge')
        
        answ = connection.response()
        # print(answ)

        for i in range(len(answ)):
            result.append(answ[i])

        # print(result)
        return result


    
    def fill_table_department(self):
        result = []
        connection.query('CountDepartments')
        
        number_of_rows = connection.response()
        number_of_rows[0] = re.sub('\(|\)|\'|,', '', number_of_rows[0])
        
        result.append(number_of_rows[0])
        
        connection.query('DistinctValues')
        distinct_departments = connection.response()
        for i in range(len(distinct_departments)):
            distinct_departments[i] = re.sub('\(|\)|\'|,', '', distinct_departments[i])
            result.append(distinct_departments[i])

        connection.query('NumberOfWorkers')
        number_of_workers = connection.response()
        normaldi = number_of_workers[0].split('\n')
        # print(normaldi)
        for i in range(len(normaldi) - 1):
            normaldi[i] = re.sub('\(|\)|\'|,', '', normaldi[i])
            result.append(normaldi[i]) 

        # print(result)
        return result

    def export_table(self, old_table, checked):
        
        table = old_table
        
        for i in range(len(checked) - 1, -1, -1):
            # print(checked[i])
            if checked[i] == False:
                table.removeRow(i)
                # print(i)
        
        row_count = table.rowCount()
        col_count = table.columnCount()

        # print(row_count, col_count)

        df_list = []
        for row in range(row_count):
            df_list2 = []
            for col in range(col_count):
                table_item = table.item(row,col)
                df_list2.append('' if table_item is None else str(table_item.text()))
            df_list.append(df_list2)

        # print(df_list)

        with open("Data_base.csv", "a", newline="") as csvfile:
            Export = csv.writer(csvfile, delimiter=";")
            for i in df_list:
                Export.writerow(i)
            csvfile.close()

    def fill_page_result(self):
        self.PageResultTable.clear()
        resp = data_base_commands.load_field(self.FullNameComboBox.currentText())

        self.PageResultTable.setRowCount(17)
        self.PageResultTable.setColumnCount(1)
        self.PageResultTable.setVerticalHeaderLabels(["Surname", "Name", "Middlename", "Birthday", "City", "Serial Number", "Date of issue", "Place of issue", "INN number", "Insurance", "Home Address", "Degree", "Specialty", "Department", "Position", "Salary", "Date of receipt"])

        for i in range(len(resp)):
            self.PageResultTable.setItem(i-1 , 0, QTableWidgetItem(re.sub('\(|\)|\'|,', '', resp[i])))
        
        self.PageResultTable.setHorizontalHeaderLabels([re.sub('\(|\)|\'|,', '', resp[1])])

        self.PageResultTable.resizeColumnsToContents()
        

    def export(self):
        dialog_export = ExportWindow()
        dialog_export.exec()
        checked = [dialog_export.SurnameCheckBox.isChecked(), dialog_export.NameCheckBox.isChecked(), dialog_export.MiddlenameCheckBox.isChecked(), dialog_export.BirthdayCheckBox.isChecked(), dialog_export.CityCheckBox.isChecked(), dialog_export.SerialNumberCheckBox.isChecked(), dialog_export.DatePasportCheckBox.isChecked(), dialog_export.PlaceOfIssueCheckBox.isChecked(), dialog_export.INNCheckBox.isChecked(), dialog_export.InsuranceNumberCheckBox.isChecked(), dialog_export.HomeAddressCheckBox.isChecked(), dialog_export.DegreeCheckBox.isChecked(), dialog_export.SpecialtyCheckBox.isChecked(), dialog_export.DepartmentCheckBox.isChecked(), dialog_export.PositionCheckBox_2.isChecked(), dialog_export.SalaryCheckBox.isChecked(), dialog_export.DateOfReceiptCheckBox.isChecked()]

        if dialog_export.buttonBox.accepted:
            self.export_table(self.FindResultTable, checked)
        


    def find(self):
        self.FindResultTable.clear()
        a = ''
        fields = [self.SurnameTextBox.text(), self.NameTextBox.text(), self.MiddlenameTextBox.text(), self.dateEdit.text(), self.PlaceOfBirthComboBox.currentText(), self.SerialNumberTextBox.text(), self.DatePasportTextBox.text(), self.PlaceOfIssueTextBox.text(), self.INNTextBox.text(), self.InsuranceNumberTextBox.text(), self.HomeAddressTextBox.text(), self.DegreeComboBox.currentText(), self.SpecialtyComboBox.currentText(), self.DepartmentComboBox.currentText(), self.PositionComboBox.currentText(), self.SalaryComboBox.currentText(), self.DateOfReceiptComboBox.currentText()]
        
        if self.TakeCheckBox.isChecked():
            fields[3] = ''
        else:
            fields[3] = self.dateEdit.text()
        
        for i in range(len(fields)):
            if fields[i] == 'Any':
                fields[i] = ''
        
        for i in fields:
            a += data_base_commands.parse(i) + ' '
        
        connection.query(a)

        resp = connection.response()
        if resp[0] != '()':
            self.Export.setEnabled(True)
            self.FindResultTable.setRowCount(17)
            self.FindResultTable.setColumnCount(len(resp)//17)
            self.FindResultTable.setVerticalHeaderLabels(["Surname", "Name", "Middlename", "Birthday", "City", "Serial Number", "Date of issue", "Place of issue", "INN number", "Insurance", "Home Address", "Degree", "Specialty", "Department", "Position", "Salary", "Date of receipt"])
            Headers = []

            for i in range(len(resp)):
                if i % 18 != 0:
                    self.FindResultTable.setItem(i%18-1 , i//18, QTableWidgetItem(re.sub('\(|\)|\'|,', '', resp[i])))
                else:
                    Headers.append(re.sub('\(|\)|\'|,', '', resp[i+1]))
                    
                self.FindResultTable.setHorizontalHeaderLabels(Headers)
                self.FindResultTable.resizeColumnsToContents()
        else:
            self.Export.setEnabled(False)
            self.FindResultTable.setRowCount(1)
            self.FindResultTable.setColumnCount(1)
            self.FindResultTable.setItem(0, 0, QTableWidgetItem('There is no such employee'))
            self.FindResultTable.resizeColumnsToContents()




    def fill_department_table(self):
        resp = self.fill_table_department()
        self.DepartmentWidget.setRowCount(int(resp[0]))
        self.DepartmentWidget.setColumnCount(2)
        self.DepartmentWidget.setHorizontalHeaderLabels(["Department", "Amount of workers"])


        for i in range(1, len(resp) - int(resp[0])):
            self.DepartmentWidget.setItem(i - 1, 0, QTableWidgetItem(resp[i]))
            self.DepartmentWidget.setItem(i - 1, 1, QTableWidgetItem(resp[i+int(resp[0])]))
        
        self.DepartmentWidget.resizeColumnsToContents()


    def fill_retirement_table(self):
        resp = self.fill_table_retirement()


        self.RetirementWidget.setRowCount(len(resp)//4)
        self.RetirementWidget.setColumnCount(4)
        self.RetirementWidget.setHorizontalHeaderLabels(["Surname", "Name", "Middlename", "Birthday"])

        for i in range(len(resp)//4):
            self.RetirementWidget.setItem(i , 0, QTableWidgetItem(resp[4*i]))
            self.RetirementWidget.setItem(i , 1, QTableWidgetItem(resp[4*i + 1]))
            self.RetirementWidget.setItem(i , 2, QTableWidgetItem(resp[4*i + 2]))
            self.RetirementWidget.setItem(i , 3, QTableWidgetItem(resp[4*i + 3]))

        self.RetirementWidget.resizeColumnsToContents()

    def admin_panel(self):
        adminWindow = AdminWindow()
        adminWindow.exec()
        if adminWindow.exit_trigger == True:
            # print("DAUN ESLI WIDESH ETO 2")
            self.fill_fullname_combobox()

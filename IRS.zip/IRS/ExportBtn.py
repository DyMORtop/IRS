# from conn import *
import re
import csv
from PyQt5 import QtCore


def export_table(old_table, checked):
    
    table = old_table
    
    for i in range(len(checked) - 1, -1, -1):
        print(checked[i])
        if checked[i] == False:
            table.removeRow(i)
            print(i)
    
    row_count = table.rowCount()
    col_count = table.columnCount()

    print(row_count, col_count)

    df_list = []
    for row in range(row_count):
        df_list2 = []
        for col in range(col_count):
            table_item = table.item(row,col)
            df_list2.append('' if table_item is None else str(table_item.text()))
        df_list.append(df_list2)

    print(df_list)

    with open("Data_base.csv", "a", newline="") as csvfile:
        Export = csv.writer(csvfile, delimiter=";")
        for i in df_list:
            Export.writerow(i)
        csvfile.close()
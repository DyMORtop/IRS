# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'auth.ui'
#
# Created by: PyQt5 UI code generator 5.13.2
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(329, 175)
        Dialog.setMinimumSize(QtCore.QSize(329, 175))
        Dialog.setMaximumSize(QtCore.QSize(329, 175))
        self.loginLine = QtWidgets.QLineEdit(Dialog)
        self.loginLine.setGeometry(QtCore.QRect(80, 50, 113, 22))
        self.loginLine.setObjectName("loginLine")
        self.passwordLine = QtWidgets.QLineEdit(Dialog)
        self.passwordLine.setGeometry(QtCore.QRect(80, 80, 113, 22))
        self.passwordLine.setEchoMode(QtWidgets.QLineEdit.Password)
        self.passwordLine.setObjectName("passwordLine")
        self.Ok = QtWidgets.QPushButton(Dialog)
        self.Ok.setGeometry(QtCore.QRect(50, 130, 93, 28))
        self.Ok.setObjectName("Ok")
        self.Cancel = QtWidgets.QPushButton(Dialog)
        self.Cancel.setGeometry(QtCore.QRect(160, 130, 93, 28))
        self.Cancel.setObjectName("Cancel")
        self.loginLabel = QtWidgets.QLabel(Dialog)
        self.loginLabel.setGeometry(QtCore.QRect(20, 50, 55, 16))
        self.loginLabel.setObjectName("loginLabel")
        self.passwordLabel = QtWidgets.QLabel(Dialog)
        self.passwordLabel.setGeometry(QtCore.QRect(20, 80, 55, 16))
        self.passwordLabel.setObjectName("passwordLabel")

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Dialog"))
        self.Ok.setText(_translate("Dialog", "OK"))
        self.Cancel.setText(_translate("Dialog", "Cancel"))
        self.loginLabel.setText(_translate("Dialog", "Login"))
        self.passwordLabel.setText(_translate("Dialog", "Password"))

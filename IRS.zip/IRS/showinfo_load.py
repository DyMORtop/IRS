from conn import *

def load_field(field):
    query(field)
    resp = response()
    return resp

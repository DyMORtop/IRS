def jopa():
    print(1)
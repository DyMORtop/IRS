import sys
from PyQt5 import QtWidgets
from PyQt5.QtWidgets import *

import design, auth, conn, parse, showinfo_load, DepartmentBtn, RetirementBtn
import re


class ExampleAuth(QtWidgets.QDialog, auth.Ui_Dialog):
    def __init__(self):

        super().__init__()
        self.setupUi(self)
    
    def check_is_not_empty(self, login_txt, password_txt):
        if len(login_txt.strip()) == 0:
            QMessageBox.warning(None, 'Warning', 'Missed login!')
            return False
        if len(password_txt.strip()) == 0:
            QMessageBox.warning(None, 'Warning', 'Missed password!')
            return False
        return True


class ExampleApp(QtWidgets.QMainWindow, design.Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.Find.clicked.connect(self.find)
        self.ShowInfo.clicked.connect(self.fill_page_result)
        self.RefreshDepartment.clicked.connect(self.fill_department_table)
        self.RefreshRetirement.clicked.connect(self.fill_retirement_table)
        res = conn.init_response()
        for i in range(len(res)):
            res[i] = re.sub('\(|\)|\'|,', '', res[i])
        self.SurenameComboBox.addItems(res)

        conn.query('birthplace')
        cities = conn.response()
        for i in range(len(cities)):
            cities[i] = re.sub('\(|\)|\'|,', '', cities[i])
        self.PlaceOfBirthComboBox.addItems(cities)
        
        conn.query('specialization')
        specialties = conn.response()
        for i in range(len(specialties)):
            specialties[i] = re.sub('\(|\)|\'|,', '', specialties[i])
        self.SpecialtyComboBox.addItems(specialties)

        conn.query('department')
        departments = conn.response()
        for i in range(len(departments)):
            departments[i] = re.sub('\(|\)|\'|,', '', departments[i])
        self.DepartmentComboBox.addItems(departments)

        conn.query('position')
        positions = conn.response()
        for i in range(len(positions)):
            positions[i] = re.sub('\(|\)|\'|,', '', positions[i])
        self.PositionComboBox.addItems(positions)

        conn.query('salary')
        salaries = conn.response()
        for i in range(len(salaries)):
            salaries[i] = re.sub('\(|\)|\'|,', '', salaries[i])
        self.SalaryComboBox.addItems(salaries)

        conn.query('datereceipt')
        dates = conn.response()
        for i in range(len(dates)):
            dates[i] = re.sub('\(|\)|\'|,', '', dates[i])
        self.DateOfReceiptComboBox.addItems(dates)

    def fill_page_result(self):
        self.PageResultWindow.clear()
        resp = showinfo_load.load_field(self.SurenameComboBox.currentText())
        for i in range(1, 18):
            self.PageResultWindow.append(re.sub('\(|\)|\'|,', '', resp[i]))

        
    def find(self):
        self.FindResultWindow.clear()
        a = ''
        fields = [self.SurnameTextBox.text(), self.NameTextBox.text(), self.MiddlenameTextBox.text(), self.dateEdit.text(), self.PlaceOfBirthComboBox.currentText(), self.SerialNumberTextBox.text(), self.DatePasportTextBox.text(), self.PlaceOfIssueTextBox.text(), self.INNTextBox.text(), self.InsuranceNumberTextBox.text(), self.HomeAddressTextBox.text(), self.DegreeComboBox.currentText(), self.SpecialtyComboBox.currentText(), self.DepartmentComboBox.currentText(), self.PositionComboBox.currentText(), self.SalaryComboBox.currentText(), self.DateOfReceiptComboBox.currentText()]
        
        if self.TakeCheckBox.isChecked():
            fields[3] = ''
        else:
            fields[3] = self.dateEdit.text()
        
        for i in range(len(fields)):
            if fields[i] == 'Any':
                fields[i] = ''
        
        for i in fields:
            a += parse.parse(i) + ' '
        
        # print(a)
        conn.query(a)

        resp = conn.response()
        try:
            for i in range(len(resp)):
                if i % 18 == 0:
                    resp[i] = '============================='
                self.FindResultWindow.append(re.sub('\(|\)|\'|,', '', resp[i])) 
            self.FindResultWindow.append('=============================') 
        except IndexError:
            self.FindResultWindow.setText('Net takogo')

    def fill_department_table(self):
        resp = DepartmentBtn.fill_table_department()


        self.DepartmentWidget.setRowCount(int(resp[0]))
        self.DepartmentWidget.setColumnCount(2)
        self.DepartmentWidget.setHorizontalHeaderLabels(["Department", "Amount of workers"])


        for i in range(1, len(resp) - int(resp[0])):
            self.DepartmentWidget.setItem(i - 1, 0, QTableWidgetItem(resp[i]))
            self.DepartmentWidget.setItem(i - 1, 1, QTableWidgetItem(resp[i+int(resp[0])]))
        
        self.DepartmentWidget.resizeColumnsToContents()




    def fill_retirement_table(self):
        resp = RetirementBtn.fill_table_retirement()


        self.RetirementWidget.setRowCount(len(resp)//4)
        self.RetirementWidget.setColumnCount(4)
        self.RetirementWidget.setHorizontalHeaderLabels(["Surname", "Name", "Middlename", "Birthday"])

        # for i in range(len(resp)):
        #     print(resp[i])
        for i in range(len(resp)//4):
            self.RetirementWidget.setItem(i , 0, QTableWidgetItem(resp[4*i]))
            self.RetirementWidget.setItem(i , 1, QTableWidgetItem(resp[4*i + 1]))
            self.RetirementWidget.setItem(i , 2, QTableWidgetItem(resp[4*i + 2]))
            self.RetirementWidget.setItem(i , 3, QTableWidgetItem(resp[4*i + 3]))
        
        self.RetirementWidget.resizeColumnsToContents()



def main():
    app = QtWidgets.QApplication(sys.argv)
    windowAuth = ExampleAuth()
    windowAuth.exec()
    while windowAuth.check_is_not_empty(windowAuth.loginLine.text(), windowAuth.passwordLine.text()) != True:
        windowAuth.loginLine.clear()
        windowAuth.passwordLine.clear()
        windowAuth.exec()
    
    window = ExampleApp()
    window.show()
    app.exec()

if __name__ == "__main__":
    main()
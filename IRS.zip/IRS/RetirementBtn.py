from conn import *
import re

def fill_table_retirement():
    result = []
    query('RetirementAge')
    
    answ = response()
    print(answ)

    for i in range(len(answ)):
        result.append(answ[i])

    print(result)
    return result
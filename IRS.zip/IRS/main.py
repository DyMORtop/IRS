import sys
# sys.path.insert(0, '../')
sys.path.append('interface/')   #ипорт из папки 
from sdfghjk import jopa        #test
from PyQt5 import QtWidgets
from PyQt5.QtWidgets import *
from MainWindow import Main_Window
# from AdminPanel import Admin
import design, auth, conn, parse, showinfo_load, DepartmentBtn, RetirementBtn, ExportBtn, export, admin
import re
from AuthenthicationWindow import ExampleAuth

def main():
    app = QtWidgets.QApplication(sys.argv)
    windowAuth = ExampleAuth()
    windowAuth.exec()
    jopa()
    if windowAuth.keys[0] == False:
        main_window = Main_Window()
        if windowAuth.keys[1] == True:
            main_window.AdminBtn.setVisible(True)
        main_window.show()
    else:
        exit(0)
    app.exec()

if __name__ =="__main__":
    main()
import sys
from PyQt5 import QtWidgets
from PyQt5.QtWidgets import *
import design, auth, conn, parse, showinfo_load, DepartmentBtn, RetirementBtn, ExportBtn, export, admin
from AdminPanel import Admin
from ExportPanel import ExportDialog
import re

class Main_Window(QtWidgets.QMainWindow, design.Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.Find.clicked.connect(self.find)
        self.ShowInfo.clicked.connect(self.fill_page_result)
        self.RefreshDepartment.clicked.connect(self.fill_department_table)
        self.RefreshRetirement.clicked.connect(self.fill_retirement_table)
        self.Export.clicked.connect(self.export)
        self.AdminBtn.clicked.connect(self.admin_panel)

        res = conn.init_response()
        for i in range(len(res)):
            res[i] = re.sub('\(|\)|\'|,', '', res[i])
        self.FullNameComboBox.addItems(res)


        conn.query('birthplace')
        cities = conn.response()
        for i in range(len(cities)):
            cities[i] = re.sub('\(|\)|\'|,', '', cities[i])
        self.PlaceOfBirthComboBox.addItems(cities)
        
        conn.query('specialization')
        specialties = conn.response()
        for i in range(len(specialties)):
            specialties[i] = re.sub('\(|\)|\'|,', '', specialties[i])
        self.SpecialtyComboBox.addItems(specialties)

        conn.query('department')
        departments = conn.response()
        for i in range(len(departments)):
            departments[i] = re.sub('\(|\)|\'|,', '', departments[i])
        self.DepartmentComboBox.addItems(departments)

        conn.query('position')
        positions = conn.response()
        for i in range(len(positions)):
            positions[i] = re.sub('\(|\)|\'|,', '', positions[i])
        self.PositionComboBox.addItems(positions)

        conn.query('salary')
        salaries = conn.response()
        for i in range(len(salaries)):
            salaries[i] = re.sub('\(|\)|\'|,', '', salaries[i])
        self.SalaryComboBox.addItems(salaries)

        conn.query('datereceipt')
        dates = conn.response()
        for i in range(len(dates)):
            dates[i] = re.sub('\(|\)|\'|,', '', dates[i])
        self.DateOfReceiptComboBox.addItems(dates)

    def fill_page_result(self):
        self.PageResultTable.clear()
        resp = showinfo_load.load_field(self.FullNameComboBox.currentText())

        self.PageResultTable.setRowCount(17)
        self.PageResultTable.setColumnCount(1)
        self.PageResultTable.setVerticalHeaderLabels(["Surname", "Name", "Middlename", "Birthday"])

        for i in range(len(resp)):
            self.PageResultTable.setItem(i-1 , 0, QTableWidgetItem(re.sub('\(|\)|\'|,', '', resp[i])))
        
        self.FindResultTable.resizeColumnsToContents()
        

    def export(self):
        dialog_export = ExportDialog()
        dialog_export.exec()
        checked = [dialog_export.SurnameCheckBox.isChecked(), dialog_export.NameCheckBox.isChecked(), dialog_export.MiddlenameCheckBox.isChecked(), dialog_export.BirthdayCheckBox.isChecked(), dialog_export.CityCheckBox.isChecked(), dialog_export.SerialNumberCheckBox.isChecked(), dialog_export.DatePasportCheckBox.isChecked(), dialog_export.PlaceOfIssueCheckBox.isChecked(), dialog_export.INNCheckBox.isChecked(), dialog_export.InsuranceNumberCheckBox.isChecked(), dialog_export.HomeAddressCheckBox.isChecked(), dialog_export.DegreeCheckBox.isChecked(), dialog_export.SpecialtyCheckBox.isChecked(), dialog_export.DepartmentCheckBox.isChecked(), dialog_export.PositionCheckBox_2.isChecked(), dialog_export.SalaryCheckBox.isChecked(), dialog_export.DateOfReceiptCheckBox.isChecked()]

        if dialog_export.buttonBox.accepted:
            ExportBtn.export_table(self.FindResultTable, checked)
        


    def find(self):    
        self.FindResultTable.clear()
        a = ''
        fields = [self.SurnameTextBox.text(), self.NameTextBox.text(), self.MiddlenameTextBox.text(), self.dateEdit.text(), self.PlaceOfBirthComboBox.currentText(), self.SerialNumberTextBox.text(), self.DatePasportTextBox.text(), self.PlaceOfIssueTextBox.text(), self.INNTextBox.text(), self.InsuranceNumberTextBox.text(), self.HomeAddressTextBox.text(), self.DegreeComboBox.currentText(), self.SpecialtyComboBox.currentText(), self.DepartmentComboBox.currentText(), self.PositionComboBox.currentText(), self.SalaryComboBox.currentText(), self.DateOfReceiptComboBox.currentText()]
        
        if self.TakeCheckBox.isChecked():
            fields[3] = ''
        else:
            fields[3] = self.dateEdit.text()
        
        for i in range(len(fields)):
            if fields[i] == 'Any':
                fields[i] = ''
        
        for i in fields:
            a += parse.parse(i) + ' '
        
        # print(a)
        conn.query(a)


        resp = conn.response()
        # try:
        self.FindResultTable.setRowCount(17)
        self.FindResultTable.setColumnCount(len(resp)//17)
        self.FindResultTable.setVerticalHeaderLabels(["Surname", "Name", "Middlename", "Birthday", "City", "Serial Number", "Date of issue", "Place of issue", "INN number", "Insurance", "Home Address", "Degree", "Specialty", "Department", "Position", "Salary", "Date of receipt"])
        for i in range(len(resp)):
            if i % 18 != 0:
                self.FindResultTable.setItem(i%18-1 , i//18, QTableWidgetItem(re.sub('\(|\)|\'|,', '', resp[i])))
            self.FindResultTable.resizeColumnsToContents()



    def fill_department_table(self):
        resp = DepartmentBtn.fill_table_department()
        self.DepartmentWidget.setRowCount(int(resp[0]))
        self.DepartmentWidget.setColumnCount(2)
        self.DepartmentWidget.setHorizontalHeaderLabels(["Department", "Amount of workers"])


        for i in range(1, len(resp) - int(resp[0])):
            self.DepartmentWidget.setItem(i - 1, 0, QTableWidgetItem(resp[i]))
            self.DepartmentWidget.setItem(i - 1, 1, QTableWidgetItem(resp[i+int(resp[0])]))
        
        self.DepartmentWidget.resizeColumnsToContents()


    def fill_retirement_table(self):
        resp = RetirementBtn.fill_table_retirement()


        self.RetirementWidget.setRowCount(len(resp)//4)
        self.RetirementWidget.setColumnCount(4)
        self.RetirementWidget.setHorizontalHeaderLabels(["Surname", "Name", "Middlename", "Birthday"])

        for i in range(len(resp)//4):
            self.RetirementWidget.setItem(i , 0, QTableWidgetItem(resp[4*i]))
            self.RetirementWidget.setItem(i , 1, QTableWidgetItem(resp[4*i + 1]))
            self.RetirementWidget.setItem(i , 2, QTableWidgetItem(resp[4*i + 2]))
            self.RetirementWidget.setItem(i , 3, QTableWidgetItem(resp[4*i + 3]))
        
        self.RetirementWidget.resizeColumnsToContents()

    def admin_panel(self):
        admin_window = Admin()
        admin_window.exec()

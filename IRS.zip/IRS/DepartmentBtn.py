from conn import *
import re

def fill_table_department():
    result = []
    query('CountDepartments')
    
    number_of_rows = response()
    number_of_rows[0] = re.sub('\(|\)|\'|,', '', number_of_rows[0])
    
    result.append(number_of_rows[0])
    
    query('DistinctValues')
    distinct_departments = response()
    for i in range(len(distinct_departments)):
        distinct_departments[i] = re.sub('\(|\)|\'|,', '', distinct_departments[i])
        result.append(distinct_departments[i])

    query('NumberOfWorkers')
    number_of_workers = response()
    normaldi = number_of_workers[0].split('\n')
    print(normaldi)
    for i in range(len(normaldi) - 1):
        normaldi[i] = re.sub('\(|\)|\'|,', '', normaldi[i])
        result.append(normaldi[i]) 

    print(result)
    return result
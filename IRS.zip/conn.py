import socket

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

client.connect(('25.47.70.141', 1807))


def init_response():

    data = client.recv(2048)
    output = data.decode()
    output = output.split('), ')
    
    return output
def response():
    
    data = client.recv(2048)

    output = data.decode()
    output.strip('\'')
    output.strip('\')')
    output = output.split(', ')

    return output

def resp_for_retirement():

    data = client.recv(2048)

    output = data.decode()

    output = output.split(',')
    return output

def query(txt_query): 
    data = txt_query
    client.send(data.encode())
    print('SENDED')
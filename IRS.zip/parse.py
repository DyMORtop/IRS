def parse(field):
    if field == '':
        return '%'
    return field



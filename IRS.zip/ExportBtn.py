# from conn import *
import re
import csv
import design


def export_table(table):

    row_count = table.rowCount()
    col_count = table.columnCount()


    df_list = []
    for row in range(row_count):
        df_list2 = []
        for col in range(col_count):
            table_item = table.item(row,col)
            df_list2.append('' if table_item is None else str(table_item.text()))
        df_list.append(df_list2)
    
    print(df_list)

    with open("test1.csv", "a", newline="") as csvfile:
        Export = csv.writer(csvfile, delimiter=";")
        for i in df_list:
            Export.writerow(i)
        csvfile.close()

    # https://www.youtube.com/watch?v=MWYRGLKMzAQ
    # tup1 = ("Bob",19)
    # writer = csv.writer(f)
    # writer.writerow(tup1)
    # print(text)
    # with open("test1.csv", "a", newline="") as csvfile:
        
    #     Export = csv.writer(csvfile, delimiter=";")#, quotechar='|', quoting=csv.QUOTE_MINIMAL)
    #     Export.writerow(["Spam" , "abs"])
    #     Export.writerow(['Spam', 'Lovely Spam', 'Wonderful Spam'])#* 5 + ['Baked Beans']
    #     csvfile.close()

# export_table()